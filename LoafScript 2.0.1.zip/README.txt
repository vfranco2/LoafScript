Run LoafGui in PowerShell.
Select desired options for install.
#############################################
Feats. 
-Adds respective oracle client 
-Checks if oracle was installed
-Checks bitlocker password cmd
-Adds Enivorment Varible
-Checks and Adds TNS files (.Ora)
-HIPA launcher
-Checks BIOS version/password
-Runs Office Updater (Still need to launch Word to force update!)

V4 6/11/2019
--------------------------------------------- 
