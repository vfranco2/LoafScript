Run loafscript in PowerShell.
Y for "facets user" installs Oracle 32 bit, N installs 64 bit.
#############################################
Feats. 
-Adds respective oracle client 
-Checks if oracle was installed
-Checks bitlocker password cmd
-Adds Enivorment Varible
-Checks and Adds TNS files (.Ora)
-HIPA launcher
-Checks BIOS version/password
-Runs Office Updater (Still need to launch Word to force update!)
-Option to restart computer

V2 5/14/2019
--------------------------------------------- 
