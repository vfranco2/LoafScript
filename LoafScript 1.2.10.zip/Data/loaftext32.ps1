Write-Host 'Oracle 32 Installed'
